using System;
using System.Collections;
using JetBrains.Annotations;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class PlayerHandler : MonoBehaviour
{
    [Header("Player Variables")]
    public GameObject Player;
    public GameObject Cam;
    public GameObject PlayerModel;
    public float WalkSpeed;
    public bool CanWalk = true;
    [Space(5)]
    
    [Header("Input")]
    public InputAction MouseDelta;
    public InputAction Forward;
    public InputAction Backward;
    public InputAction Right;
    public InputAction Left;
    public InputAction Backout;
    public InputAction Attack;
    [Space(5)]

    [Header("Camera Variables")]
    public float CamDist_Y;
    public float CamDist_X;
    public float CamDist_Z;
    public bool FollowPlayer = true;
    public float Lagtime = 3;
    private Vector3 SmoothDampVel;

    float ScrnSize_X;
    float ScrnSize_Y;

    [Space(5)]
    [Header("UI")]
    public GameObject ShopUI;
    public UIDocument ShopUiDoc;
    public VisualElement Root;
    public Button CloseButton;
    public bool ShopOpen = false;
    [Space(5)]
    public Rigidbody RB;

    [Header("Action")]
    public GameObject Pickaxe;
    public Collider PickaxeCollider; // Drag the Pickaxe's Trigger Collider here
    public float MiningDamage = 25f;
    private int PickaxeState = 0; 
    public float SwingForward = 135;
    public float SwingBack = 45;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void OnEnable()
    {
        MouseDelta.Enable();
        Forward.Enable();
        Backward.Enable();
        Right.Enable();
        Left.Enable();
        Backout.Enable();
        Attack.Enable();
    }
    void OnDisable()
    {
        MouseDelta.Disable();
        Forward.Disable();
        Backward.Disable();
        Right.Disable();
        Left.Disable();
        Backout.Disable();
        Attack.Enable();
    }

    void Awake()
    {
        ScrnSize_X = Screen.width/2;
        ScrnSize_Y = Screen.height/2;
    }
    void Start()
    {
        Root = ShopUiDoc.rootVisualElement;
        Root.style.display = DisplayStyle.None;
        CloseButton = Root.Q<Button>("Close");
        CloseButton.clicked += () => {Root.style.display = DisplayStyle.None; ShopOpen = false; CanWalk = true;};
    }

    // Update is called once per frame
    void Update()
    {
        HandlePlayer();
        if (ShopOpen && Backout.WasPressedThisFrame())
        {
            CloseShopMenu();
        }
        //CamHandler();
        if (Attack.WasPressedThisFrame())
        {
            StartCoroutine(SwingPickaxe());
        }
    }

    public void HandlePlayer()
    {
        if (CanWalk) {
            Vector3 MoveDirection = Vector3.zero;


            if (Forward.IsPressed())
            {
                MoveDirection += Cam.transform.forward;
            } else if (Backward.IsPressed())
            {
                MoveDirection -= Cam.transform.forward;
            }
            if (Right.IsPressed())
            {
                MoveDirection += Cam.transform.right;
            } else if (Left.IsPressed())
            {
                MoveDirection -= Cam.transform.right;
            }
            MoveDirection = Vector3.ProjectOnPlane(MoveDirection, Vector3.up);
            MoveDirection.Normalize();
            MovePlayer(MoveDirection, WalkSpeed);
            Cam.transform.position = PlayerModel.transform.position + new Vector3(CamDist_X, CamDist_Y, CamDist_Z);
            Cam.transform.LookAt(PlayerModel.transform.position);
            HandleModelRotation();
            
        }
    }
    public void MovePlayer(Vector3 Direction, float Speed)
    {
        //transform.Translate(Direction * Speed * Time.deltaTime, Space.World);
        RB.MovePosition(RB.position + Direction * Speed * Time.deltaTime);
    }

    public void HandleShopMenu()
    {
        Root.style.display = DisplayStyle.Flex;
        CanWalk = false;
        ShopOpen = true;
    }
    public void CloseShopMenu()
    {
        Root.style.display = DisplayStyle.None;
        CanWalk = true;
        ShopOpen = false;
    }

    /*void CamHandler()
    {
        Vector3 NewPos = PlayerModel.transform.position + new Vector3(CamDist_X, CamDist_Y, CamDist_Z);
        if (FollowPlayer)
        {
            Cam.transform.position = Vector3.SmoothDamp(Cam.transform.position, NewPos, ref SmoothDampVel, Lagtime * Time.deltaTime);
            //Cam.transform.LookAt(PlayerModel.transform.position);
        }
    }*/

    void HandleModelRotation()
    {
        /*
        //Debug.Log("x: " + (Screen.width/2) + " Y:" + (Screen.height/2));
        //Debug.Log("x = " + Mouse.current.position.x.ReadValue() + "y = " + Mouse.current.position.y);
        Vector2 MousePos = Mouse.current.position.ReadValue();

        float Adjacent = MousePos.x - ScrnSize_X;
        float Opposite = MousePos.y - ScrnSize_Y; 

        float Angle = Mathf.Atan2(Opposite, Adjacent) * Mathf.Rad2Deg;
        PlayerModel.transform.rotation = Quaternion.Euler(0, Angle, 0);
        */
        Ray ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());
        Plane groundPlane = new Plane(Vector3.up, Vector3.zero);

        if (groundPlane.Raycast(ray, out float distance))
        {
            Vector3 worldPoint = ray.GetPoint(distance);
            Vector3 AimedPos = worldPoint - PlayerModel.transform.position;
            PlayerModel.transform.forward = new Vector3(AimedPos.x, 0, AimedPos.z);
        }
        
    }

    public void TeleportToScene(String SCENE_NAME)
    {
        try
        {
            SceneManager.LoadScene(SCENE_NAME);
        } catch
        {
            Debug.Log("SCENE DOES NOT EXIST:" + SCENE_NAME);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // This only runs if the PickaxeCollider is enabled during the swing
        if (PickaxeState == 1 && other.CompareTag("Mineral"))
        {
            if (other.TryGetComponent<MineralScript>(out MineralScript mineral))
            {
                mineral.TakeDamage(MiningDamage);
                // Disable collider after hit so we don't hit 100 times in one swing
                PickaxeCollider.enabled = false; 
            }
        }
    }

    IEnumerator SwingPickaxe()
    {
        if (PickaxeState == 0)
        {
            PickaxeState = 1;
            if(PickaxeCollider != null) PickaxeCollider.enabled = true; // Enable trigger

            float TweenDur = 0.2f;
            float Current = 0f;
            float Value = 0f;
    
            while (Current < TweenDur)
            {
                Value = Mathf.Lerp(SwingBack, SwingForward, Current / TweenDur);
                Pickaxe.transform.localRotation = Quaternion.Euler(0, Value, -90);
                Current += Time.deltaTime;
                yield return null; // Better than WaitForSeconds(0.01) for smooth lerping
            }

            // Reset
            Pickaxe.transform.localRotation = Quaternion.Euler(0, SwingBack, -90);
            if(PickaxeCollider != null) PickaxeCollider.enabled = false; // Disable trigger
            PickaxeState = 0;
        }
    }
}
