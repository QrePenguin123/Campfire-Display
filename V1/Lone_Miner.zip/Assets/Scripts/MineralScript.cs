using UnityEngine;

public class MineralScript : MonoBehaviour
{
    [Header("Mineral Settings")]
    public float Health = 100f;

    public void TakeDamage(float amount)
    {
        Health -= amount;
        Debug.Log($"{gameObject.name} took damage. Remaining: {Health}");

        if (Health <= 0)
        {
            Break();
        }
    }

    private void Break()
    {
        
        Destroy(gameObject);
    }
}