using UnityEngine;

public class Void : MonoBehaviour
{
    public GameObject Player;
    public PlayerHandler Handler;
    public GameObject Playermodel;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Handler = Player.GetComponent<PlayerHandler>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "PlayerModel")
        {
            Playermodel.transform.position = new Vector3(0, 1, 0);
        }
    }
}
