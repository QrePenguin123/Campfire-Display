using UnityEngine;

public class Shop : MonoBehaviour
{
    public GameObject Player;
    public PlayerHandler Handler;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Handler = Player.GetComponent<PlayerHandler>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "PlayerModel")
        {
            Handler.HandleShopMenu();
        }
    }
}
