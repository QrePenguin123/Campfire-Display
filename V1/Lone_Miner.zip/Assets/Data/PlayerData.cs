using JetBrains.Annotations;
using UnityEngine;

[CreateAssetMenu(fileName = "PlayerData", menuName = "Scriptable Objects/PlayerData")]
public class PlayerData : ScriptableObject
{
    //level and hp
    public int PlayerLevel = 0;
    public int Hp = 5;
    //upgradable multipliyer
    public int MiningStrength = 1;
    public int MovementSpeed = 1;
    public int AttackMultiplier = 1;
    //dif
    public float Global_Difficulty_Multiplier = 1f;
    //Playtime
    public float InMineTime = 0f;
    //currency and resources
    public int currency = 0;
    public int Iron = 0;
    public int Tungsten = 0;
    public int Kryptonite = 0;
}
